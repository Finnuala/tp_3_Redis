﻿using NotesApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using StackExchange.Redis;
using System.Web;

namespace NotesApplication.Controllers
{
    public class NotesController : ApiController
    {
        string hashKey = "hashNotes";
        string contenuNotes = "";
        Connexion connexion = new Connexion();
        IDatabase db;
        public IHttpActionResult GetNotes()
        {
            db = connexion.OpenConnexion();
            int index = 1;
            var notes = db.HashKeys(hashKey);
            foreach(var note in notes)
            {
                contenuNotes += String.Concat(index, " ", db.HashGet(hashKey, note), "              ");
                index++;
            }

            return Ok(contenuNotes);
        }

        public IHttpActionResult GetNote(string id)
        {
            db = connexion.OpenConnexion();

            return Ok(db.HashGet(hashKey, id));
        }
        
        public IHttpActionResult PostNote()
        {
            Guid id = Guid.NewGuid();
            string dataContent = this.Request.Content.ReadAsStringAsync().Result;

            db = connexion.OpenConnexion();

            HashEntry[] redisHash = { new HashEntry(id.ToString(), dataContent) };
            db.HashSet(hashKey, redisHash);
            return Ok(id.ToString());
        }

        public IHttpActionResult Delete(string id)
        {
            db = connexion.OpenConnexion();

            db.HashDelete(hashKey, id);
            return Ok("Suppression de la ressource " + id + " effectuée");
        }
    }
}
