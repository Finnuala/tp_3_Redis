﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NotesApplication.Models
{
    public class Notes
    {
        private int id { get; set; }
        private string contenu { get; set; }

        public Notes(int id, string contenu)
        {
            this.id = id;
            this.contenu = contenu;
        }
    }
}