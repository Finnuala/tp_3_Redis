﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NotesApplication.Models
{
    public class Connexion
    {
        public Connexion()
        {

        }

        public IDatabase OpenConnexion()
        {
            ConnectionMultiplexer redis = ConnectionMultiplexer.Connect("192.168.8.177,password=foobared");
            return redis.GetDatabase();
        }
    }
}