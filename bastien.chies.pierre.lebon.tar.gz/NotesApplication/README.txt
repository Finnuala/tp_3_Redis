Notre API Web a �t� r�alis�e en ASP .net avec un serveur IIS (lanc� en local et �coutant sur le port 8080).
Elle communique avec une VM Ubuntu sur laquelle est h�berg�e notre Redis et dont l'adresse IP est : 192.168.8.177.

Notre API g�re les requ�tes HTTP : Get, Post et Delete.

La gestion de ces requ�tes est pr�sente dans le fichier Controllers/NotesController.cs

Afin de l'utiliser il faut donc :
1- ex�cuter le .sln de la solution (NotesApplication.sln)
2- run la solution (qui va lancer le serveur IIS)
3- ouvrir un cmd et ex�cuter les commandes cUrl souhait�es


Notes : 
* <curl -H "Content-Type:text/plain" --data 'Penser au pain' http://localhost:8080> ne fonctionnera qu'en rempla�ant les simples c�tes par des doubles.
* il sera peut �tre n�cessaire de changer dans la classe Connexion.cs les cha�nes de connexion pour Redis.